import { useEffect, useState } from "react";
import { mockApi, type Medicine, type Bill } from "@/services/api";
import StatCard from "@/components/StatCard";
import { Card } from "@/components/ui/card";
import { Pill, Users, Receipt, AlertTriangle, TrendingUp, Clock } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

const Dashboard = () => {
  const { user } = useAuth();
  const [meds, setMeds] = useState<Medicine[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);
  const [custCount, setCustCount] = useState(0);

  useEffect(() => {
    Promise.all([mockApi.listMedicines(), mockApi.listBills(), mockApi.listCustomers()])
      .then(([m, b, c]) => { setMeds(m); setBills(b); setCustCount(c.length); });
  }, []);

  const lowStock = meds.filter((m) => m.quantity > 0 && m.quantity < 20);
  const outOfStock = meds.filter((m) => m.quantity === 0);
  const totalRevenue = bills.reduce((s, b) => s + b.grandTotal, 0);
  const todayBills = bills.filter((b) => new Date(b.date).toDateString() === new Date().toDateString());

  return (
    <div className="container py-8 space-y-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl md:text-4xl font-display font-bold tracking-tight">
          Good day, <span className="gradient-text">{user?.name}</span>
        </h1>
        <p className="text-muted-foreground mt-1">Here's what's happening at your pharmacy today.</p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Medicines" value={meds.length} icon={Pill} trend="+12%" delay={0} />
        <StatCard label="Customers" value={custCount} icon={Users} trend="+5%" delay={0.1} />
        <StatCard label="Today's Bills" value={todayBills.length} icon={Receipt} delay={0.2} accent="success" />
        <StatCard label="Total Revenue" value={`₹${totalRevenue.toLocaleString("en-IN")}`} icon={TrendingUp} trend="+18%" delay={0.3} accent="success" />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-6 bg-gradient-card border-border/60 shadow-card-soft">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold text-lg">Recent Bills</h2>
            <Badge variant="outline">{bills.length} total</Badge>
          </div>
          {bills.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Receipt className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm">No bills yet. Create your first bill from the Billing page.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {bills.slice(0, 6).map((b) => (
                <div key={b.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-secondary/50 transition-colors">
                  <div>
                    <div className="font-medium">{b.customerName}</div>
                    <div className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {new Date(b.date).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-display font-bold">₹{b.grandTotal.toLocaleString("en-IN")}</div>
                    <div className="text-xs text-muted-foreground">{b.items.length} items</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card className="p-6 bg-gradient-card border-border/60 shadow-card-soft">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="h-5 w-5 text-warning" />
            <h2 className="font-display font-semibold text-lg">Stock Alerts</h2>
          </div>
          <div className="space-y-2 max-h-80 overflow-auto">
            {outOfStock.map((m) => (
              <div key={m.id} className="p-3 rounded-lg bg-destructive/5 border border-destructive/20">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-sm">{m.name}</span>
                  <Badge variant="destructive" className="text-[10px]">OUT</Badge>
                </div>
              </div>
            ))}
            {lowStock.map((m) => (
              <div key={m.id} className="p-3 rounded-lg bg-warning/5 border border-warning/30">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-sm">{m.name}</span>
                  <span className="text-xs font-mono font-semibold text-warning">{m.quantity} left</span>
                </div>
              </div>
            ))}
            {lowStock.length === 0 && outOfStock.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-6">All stock levels healthy ✓</p>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
