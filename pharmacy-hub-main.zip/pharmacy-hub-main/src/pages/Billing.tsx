import { useEffect, useState } from "react";
import { useCart } from "@/context/CartContext";
import { mockApi, type Customer } from "@/services/api";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Receipt, Trash2, Minus, Plus, ShoppingCart, FileText, Printer } from "lucide-react";
import { toast } from "react-hot-toast";
import { motion, AnimatePresence } from "framer-motion";

const TAX_RATE = 0.05;

const Billing = () => {
  const { items, remove, setQty, clear, subtotal } = useCart();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [customerId, setCustomerId] = useState<string>("");
  const [generated, setGenerated] = useState<{ id: number; date: string } | null>(null);

  useEffect(() => { mockApi.listCustomers().then(setCustomers); }, []);

  const tax = +(subtotal * TAX_RATE).toFixed(2);
  const grandTotal = +(subtotal + tax).toFixed(2);

  const generateBill = async () => {
    if (!customerId) return toast.error("Select a customer");
    if (!items.length) return toast.error("Cart is empty");
    const cust = customers.find((c) => c.id === +customerId)!;
    const bill = await mockApi.createBill({
      customerId: cust.id, customerName: cust.name,
      items: items.map((i) => ({ medicineId: i.medicine.id, name: i.medicine.name, price: i.medicine.price, quantity: i.quantity })),
      total: subtotal, tax, grandTotal,
    });
    toast.success(`Bill #${bill.id} created`);
    setGenerated({ id: bill.id, date: bill.date });
    clear();
  };

  return (
    <div className="container py-8 space-y-6">
      <div>
        <h1 className="text-3xl md:text-4xl font-display font-bold tracking-tight flex items-center gap-3">
          <Receipt className="h-8 w-8 text-primary" /> Billing
        </h1>
        <p className="text-muted-foreground mt-1">Create a new invoice for your customer</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-6 bg-gradient-card border-border/60 shadow-card-soft">
          <h2 className="font-display font-semibold text-lg mb-4 flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" /> Cart Items
          </h2>

          {items.length === 0 ? (
            <div className="text-center py-16">
              <ShoppingCart className="h-16 w-16 mx-auto mb-4 text-muted-foreground/30" />
              <p className="font-medium mb-1">Your cart is empty</p>
              <p className="text-sm text-muted-foreground">Add medicines from the Medicines page</p>
            </div>
          ) : (
            <div className="space-y-2">
              <AnimatePresence>
                {items.map((it) => (
                  <motion.div
                    key={it.medicine.id}
                    layout
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-secondary/40"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{it.medicine.name}</div>
                      <div className="text-xs text-muted-foreground">₹{it.medicine.price} × {it.quantity}</div>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setQty(it.medicine.id, it.quantity - 1)}><Minus className="h-3 w-3" /></Button>
                      <Input className="h-7 w-14 text-center" type="number" value={it.quantity} onChange={(e) => setQty(it.medicine.id, +e.target.value)} />
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setQty(it.medicine.id, it.quantity + 1)}><Plus className="h-3 w-3" /></Button>
                    </div>
                    <div className="font-display font-bold w-20 text-right">₹{(it.medicine.price * it.quantity).toFixed(2)}</div>
                    <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => remove(it.medicine.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </Card>

        <Card className="p-6 bg-gradient-card border-border/60 shadow-card-soft h-fit lg:sticky lg:top-20">
          <h2 className="font-display font-semibold text-lg mb-4 flex items-center gap-2">
            <FileText className="h-5 w-5" /> Invoice Summary
          </h2>

          <div className="space-y-4 mb-4">
            <div className="space-y-1.5">
              <Label>Customer</Label>
              <Select value={customerId} onValueChange={setCustomerId}>
                <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
                <SelectContent>
                  {customers.map((c) => <SelectItem key={c.id} value={c.id.toString()}>{c.name} · {c.phone}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2 py-4 border-y border-border/60 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>₹{subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Tax ({(TAX_RATE * 100).toFixed(0)}%)</span><span>₹{tax.toFixed(2)}</span></div>
            <div className="flex justify-between font-display font-bold text-lg pt-2"><span>Grand Total</span><span className="gradient-text">₹{grandTotal.toFixed(2)}</span></div>
          </div>

          <Button onClick={generateBill} disabled={!items.length} className="w-full mt-4 h-11 bg-gradient-primary shadow-md-soft">
            Generate Bill
          </Button>

          {generated && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mt-4 p-3 rounded-lg bg-success/10 border border-success/30 text-sm">
              <div className="flex items-center justify-between">
                <span>Bill #{generated.id} created ✓</span>
                <Button size="sm" variant="ghost" onClick={() => window.print()}><Printer className="h-3.5 w-3.5 mr-1" /> Print</Button>
              </div>
            </motion.div>
          )}
        </Card>
      </div>
    </div>
  );
};

export default Billing;
