import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useNavigate, Navigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Pill, Loader2, ShieldCheck, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import heroImg from "@/assets/pharmacy-hero.jpg";

const Login = () => {
  const { login, user } = useAuth();
  const nav = useNavigate();
  const [creds, setCreds] = useState({ username: "", password: "" });
  const [loading, setLoading] = useState(false);

  if (user) return <Navigate to="/dashboard" replace />;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const ok = await login(creds.username.trim(), creds.password);
    setLoading(false);
    if (ok) nav("/dashboard");
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-background">
      {/* Hero side */}
      <div className="relative hidden lg:flex flex-col justify-between p-12 bg-gradient-hero overflow-hidden">
        <div className="absolute inset-0 mesh-bg opacity-30" />
        <div className="relative flex items-center gap-2 text-primary-foreground">
          <div className="h-10 w-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <Pill className="h-5 w-5" />
          </div>
          <span className="font-display font-bold text-xl">MediBill</span>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="relative z-10"
        >
          <img src={heroImg} alt="Pharmacy" width={1280} height={896} className="rounded-2xl shadow-2xl mb-8 animate-float" />
          <h1 className="text-4xl font-display font-bold text-primary-foreground leading-tight mb-3">
            Pharmacy management,<br />reimagined.
          </h1>
          <p className="text-primary-foreground/80 max-w-md">
            Inventory, billing, customers and reports — all in one beautifully crafted workspace built for modern pharmacies.
          </p>
        </motion.div>

        <div className="relative flex items-center gap-6 text-primary-foreground/90 text-sm">
          <div className="flex items-center gap-2"><ShieldCheck className="h-4 w-4" /> JWT secured</div>
          <div className="flex items-center gap-2"><Sparkles className="h-4 w-4" /> Real-time sync</div>
        </div>
      </div>

      {/* Form side */}
      <div className="flex items-center justify-center p-6 lg:p-12 mesh-bg">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <div className="lg:hidden flex items-center gap-2 mb-6 justify-center">
            <div className="h-10 w-10 rounded-xl bg-gradient-primary flex items-center justify-center">
              <Pill className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-display font-bold text-xl gradient-text">MediBill</span>
          </div>

          <Card className="p-8 shadow-lg-soft border-border/60 bg-gradient-card">
            <div className="mb-6">
              <h2 className="text-2xl font-display font-bold">Welcome back</h2>
              <p className="text-muted-foreground text-sm mt-1">Sign in to your pharmacy dashboard</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  placeholder="admin or staff"
                  value={creds.username}
                  onChange={(e) => setCreds({ ...creds, username: e.target.value })}
                  required
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={creds.password}
                  onChange={(e) => setCreds({ ...creds, password: e.target.value })}
                  required
                  className="h-11"
                />
              </div>

              <Button type="submit" disabled={loading} className="w-full h-11 bg-gradient-primary hover:opacity-90 shadow-md-soft">
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Sign In"}
              </Button>
            </form>

            <div className="mt-6 p-3 rounded-lg bg-secondary/60 text-xs text-secondary-foreground">
              <strong>Demo:</strong> use <code className="font-mono">admin</code> for admin access, anything else for staff. Password can be any value.
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default Login;
