import axios from "axios";
import { toast } from "react-hot-toast";

export const api = axios.create({
  baseURL: "/api",
  headers: { "Content-Type": "application/json" },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem("token");
      localStorage.removeItem("role");
      if (window.location.pathname !== "/login") window.location.href = "/login";
    }
    const msg = err.response?.data?.message || err.message || "Request failed";
    if (err.response?.status !== 401) toast.error(msg);
    return Promise.reject(err);
  }
);

// ----- Mock data layer (swap with real Spring Boot backend) -----
export type Medicine = {
  id: number;
  name: string;
  brand: string;
  category: string;
  price: number;
  quantity: number;
  expiryDate: string;
  batchNo: string;
};
export type Customer = { id: number; name: string; phone: string; email: string; address: string };
export type BillItem = { medicineId: number; name: string; price: number; quantity: number };
export type Bill = { id: number; customerId: number; customerName: string; items: BillItem[]; total: number; tax: number; grandTotal: number; date: string };

const seedMedicines: Medicine[] = [
  { id: 1, name: "Paracetamol 500mg", brand: "Crocin", category: "Analgesic", price: 25, quantity: 240, expiryDate: "2026-08-15", batchNo: "PCM-2024-A1" },
  { id: 2, name: "Amoxicillin 250mg", brand: "Mox", category: "Antibiotic", price: 85, quantity: 120, expiryDate: "2025-12-10", batchNo: "AMX-2024-B2" },
  { id: 3, name: "Cetirizine 10mg", brand: "Zyrtec", category: "Antihistamine", price: 35, quantity: 8, expiryDate: "2026-03-22", batchNo: "CTZ-2024-C3" },
  { id: 4, name: "Ibuprofen 400mg", brand: "Brufen", category: "Analgesic", price: 45, quantity: 180, expiryDate: "2026-11-05", batchNo: "IBU-2024-D4" },
  { id: 5, name: "Omeprazole 20mg", brand: "Prilosec", category: "Antacid", price: 95, quantity: 65, expiryDate: "2026-06-18", batchNo: "OMP-2024-E5" },
  { id: 6, name: "Metformin 500mg", brand: "Glucophage", category: "Antidiabetic", price: 55, quantity: 200, expiryDate: "2027-01-30", batchNo: "MET-2024-F6" },
  { id: 7, name: "Atorvastatin 10mg", brand: "Lipitor", category: "Cardiovascular", price: 120, quantity: 90, expiryDate: "2026-09-14", batchNo: "ATR-2024-G7" },
  { id: 8, name: "Vitamin D3 60K", brand: "Calcirol", category: "Supplement", price: 65, quantity: 4, expiryDate: "2026-04-20", batchNo: "VTD-2024-H8" },
  { id: 9, name: "Azithromycin 500mg", brand: "Azithral", category: "Antibiotic", price: 145, quantity: 75, expiryDate: "2026-07-08", batchNo: "AZI-2024-I9" },
  { id: 10, name: "Pantoprazole 40mg", brand: "Pantop", category: "Antacid", price: 75, quantity: 110, expiryDate: "2026-10-25", batchNo: "PAN-2024-J0" },
];

const seedCustomers: Customer[] = [
  { id: 1, name: "Rohit Sharma", phone: "+91 98765 43210", email: "rohit@example.com", address: "Pune, Maharashtra" },
  { id: 2, name: "Priya Iyer", phone: "+91 90123 45678", email: "priya@example.com", address: "Bengaluru, Karnataka" },
  { id: 3, name: "Anjali Mehta", phone: "+91 88990 11223", email: "anjali@example.com", address: "Mumbai, Maharashtra" },
];

const KEYS = { MEDS: "pb_medicines", CUSTS: "pb_customers", BILLS: "pb_bills" };

const load = <T,>(k: string, fallback: T): T => {
  try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
};
const save = (k: string, v: unknown) => localStorage.setItem(k, JSON.stringify(v));

export const mockApi = {
  // Auth
  login: async (username: string, password: string) => {
    await new Promise((r) => setTimeout(r, 500));
    if (!username || !password) throw new Error("Enter username and password");
    const role = username.toLowerCase() === "admin" ? "ADMIN" : "USER";
    return { token: `mock.${btoa(username)}.${Date.now()}`, role, name: username };
  },
  // Medicines
  listMedicines: async (): Promise<Medicine[]> => {
    let m = load<Medicine[]>(KEYS.MEDS, []);
    if (!m.length) { save(KEYS.MEDS, seedMedicines); m = seedMedicines; }
    return m;
  },
  saveMedicine: async (med: Medicine): Promise<Medicine> => {
    const all = load<Medicine[]>(KEYS.MEDS, seedMedicines);
    if (med.id) {
      const idx = all.findIndex((x) => x.id === med.id);
      if (idx >= 0) all[idx] = med;
    } else {
      med.id = Math.max(0, ...all.map((x) => x.id)) + 1;
      all.push(med);
    }
    save(KEYS.MEDS, all);
    return med;
  },
  deleteMedicine: async (id: number) => {
    const all = load<Medicine[]>(KEYS.MEDS, seedMedicines).filter((x) => x.id !== id);
    save(KEYS.MEDS, all);
  },
  // Customers
  listCustomers: async (): Promise<Customer[]> => {
    let c = load<Customer[]>(KEYS.CUSTS, []);
    if (!c.length) { save(KEYS.CUSTS, seedCustomers); c = seedCustomers; }
    return c;
  },
  saveCustomer: async (c: Customer): Promise<Customer> => {
    const all = load<Customer[]>(KEYS.CUSTS, seedCustomers);
    if (c.id) {
      const idx = all.findIndex((x) => x.id === c.id);
      if (idx >= 0) all[idx] = c;
    } else {
      c.id = Math.max(0, ...all.map((x) => x.id)) + 1;
      all.push(c);
    }
    save(KEYS.CUSTS, all);
    return c;
  },
  deleteCustomer: async (id: number) => {
    const all = load<Customer[]>(KEYS.CUSTS, seedCustomers).filter((x) => x.id !== id);
    save(KEYS.CUSTS, all);
  },
  // Bills
  listBills: async (): Promise<Bill[]> => load<Bill[]>(KEYS.BILLS, []),
  createBill: async (b: Omit<Bill, "id" | "date">): Promise<Bill> => {
    const all = load<Bill[]>(KEYS.BILLS, []);
    const bill: Bill = { ...b, id: Math.max(0, ...all.map((x) => x.id)) + 1, date: new Date().toISOString() };
    all.unshift(bill);
    save(KEYS.BILLS, all);
    // decrement stock
    const meds = load<Medicine[]>(KEYS.MEDS, seedMedicines);
    bill.items.forEach((it) => {
      const m = meds.find((x) => x.id === it.medicineId);
      if (m) m.quantity = Math.max(0, m.quantity - it.quantity);
    });
    save(KEYS.MEDS, meds);
    return bill;
  },
};
